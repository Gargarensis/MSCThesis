package be.ppareit.shutdown;


public class SdSettings {

    private static final String TAG = SdSettings.class.getSimpleName();

}
