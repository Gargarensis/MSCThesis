package ca.farrelltonsolar.classic;

public enum MQTT_Type {
    Off,
    Subscriber,
    Publisher
}