package ch.logixisland.anuto.util.iterator;

public interface Predicate<T> {
    boolean apply(T value);
}
