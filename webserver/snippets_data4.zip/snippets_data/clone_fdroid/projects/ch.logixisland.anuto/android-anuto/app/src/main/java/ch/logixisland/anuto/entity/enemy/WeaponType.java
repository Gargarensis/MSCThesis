package ch.logixisland.anuto.entity.enemy;

public enum WeaponType {
    None,
    Bullet,
    Laser,
    Explosive
}
