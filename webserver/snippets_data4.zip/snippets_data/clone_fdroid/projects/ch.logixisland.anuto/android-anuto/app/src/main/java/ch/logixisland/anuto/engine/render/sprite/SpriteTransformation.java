package ch.logixisland.anuto.engine.render.sprite;

public interface SpriteTransformation {
    void draw(SpriteInstance sprite, SpriteTransformer transformer);
}
