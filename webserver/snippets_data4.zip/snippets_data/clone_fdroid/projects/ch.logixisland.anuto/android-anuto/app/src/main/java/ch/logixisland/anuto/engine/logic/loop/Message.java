package ch.logixisland.anuto.engine.logic.loop;

public interface Message {
    void execute();
}
