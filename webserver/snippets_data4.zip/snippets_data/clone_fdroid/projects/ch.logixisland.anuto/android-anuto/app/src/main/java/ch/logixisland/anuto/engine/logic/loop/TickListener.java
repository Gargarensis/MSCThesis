package ch.logixisland.anuto.engine.logic.loop;

public interface TickListener {
    void tick();
}
