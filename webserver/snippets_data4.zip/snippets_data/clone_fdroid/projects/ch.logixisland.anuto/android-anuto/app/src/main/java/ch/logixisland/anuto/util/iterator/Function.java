package ch.logixisland.anuto.util.iterator;

public interface Function<F, T> {
    T apply(F input);
}
