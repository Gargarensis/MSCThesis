/** Automatically generated file. DO NOT MODIFY */
package com.achep.widget.jellyclock;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}