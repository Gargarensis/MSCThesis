package com.botbrew.basil;

public interface TitleFragment {
	public String getTitle();
}