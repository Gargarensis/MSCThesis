package com.anysoftkeyboard.themes.three_d.pack;

import com.anysoftkeyboard.addon.PackBroadcastReceiverBase;

public class PackBroadcastReceiver extends PackBroadcastReceiverBase {
}
