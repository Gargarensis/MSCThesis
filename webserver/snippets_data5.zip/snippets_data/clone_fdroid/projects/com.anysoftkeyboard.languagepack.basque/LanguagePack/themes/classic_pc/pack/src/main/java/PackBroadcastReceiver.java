package com.anysoftkeyboard.themes.classic_pc.pack;

import com.anysoftkeyboard.addon.PackBroadcastReceiverBase;

public class PackBroadcastReceiver extends PackBroadcastReceiverBase {
}
