package com.anysoftkeyboard.languagepack.hebrew;

import com.anysoftkeyboard.addon.PackBroadcastReceiverBase;

public class PackBroadcastReceiver extends PackBroadcastReceiverBase {

}
