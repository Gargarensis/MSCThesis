package com.anysoftkeyboard.languagepack.catalan;

import com.anysoftkeyboard.addon.PackBroadcastReceiverBase;

public class PackBroadcastReceiver extends PackBroadcastReceiverBase {

}
