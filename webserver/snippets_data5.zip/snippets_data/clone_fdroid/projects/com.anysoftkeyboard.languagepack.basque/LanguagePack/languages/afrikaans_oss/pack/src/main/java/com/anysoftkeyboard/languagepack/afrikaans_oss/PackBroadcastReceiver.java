package com.anysoftkeyboard.languagepack.afrikaans_oss;

import com.anysoftkeyboard.addon.PackBroadcastReceiverBase;

public class PackBroadcastReceiver extends PackBroadcastReceiverBase {

}
