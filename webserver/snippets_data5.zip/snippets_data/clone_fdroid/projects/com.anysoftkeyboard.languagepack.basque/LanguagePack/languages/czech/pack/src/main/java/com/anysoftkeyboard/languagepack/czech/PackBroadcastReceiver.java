package com.anysoftkeyboard.languagepack.czech;

import com.anysoftkeyboard.addon.PackBroadcastReceiverBase;

public class PackBroadcastReceiver extends PackBroadcastReceiverBase {

}
