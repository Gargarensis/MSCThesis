package com.anysoftkeyboard.quicktextkeys.bbcodeskeykey;

import com.anysoftkeyboard.addon.PackBroadcastReceiverBase;

public class KeyBroadcastReceiver extends PackBroadcastReceiverBase {
}