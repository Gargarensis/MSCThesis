package com.anysoftkeyboard.addon;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class PackBroadcastReceiverBase extends BroadcastReceiver {

    @Override
    public void onReceive(Context arg0, Intent arg1) {

    }

}
