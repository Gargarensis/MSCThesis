package com.beemdevelopment.aegis.db.slots;

public class SlotIntegrityException extends Exception {
    public SlotIntegrityException() {

    }

    public SlotIntegrityException(Throwable cause) {
        super(cause);
    }
}
