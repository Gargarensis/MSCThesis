package com.beemdevelopment.aegis.encoding;

public class Base32Exception extends Exception {
    public Base32Exception(String message) {
        super(message);
    }
}
