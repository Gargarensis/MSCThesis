package com.beemdevelopment.aegis.crypto;

public class KeyStoreHandleException extends Exception {
    public KeyStoreHandleException(Throwable cause) {
        super(cause);
    }

    public KeyStoreHandleException(String message) {
        super(message);
    }
}
