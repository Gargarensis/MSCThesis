package com.beemdevelopment.aegis.db.slots;

public class SlotListException extends Exception {
    public SlotListException(Throwable cause) {
        super(cause);
    }

    public SlotListException(String message) {
        super(message);
    }
}
