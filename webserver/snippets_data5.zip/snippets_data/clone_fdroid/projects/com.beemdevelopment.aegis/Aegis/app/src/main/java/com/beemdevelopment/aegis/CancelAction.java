package com.beemdevelopment.aegis;

public enum CancelAction {
    KILL,
    CLOSE
}

