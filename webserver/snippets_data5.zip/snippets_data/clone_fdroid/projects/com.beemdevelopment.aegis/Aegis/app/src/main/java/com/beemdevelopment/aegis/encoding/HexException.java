package com.beemdevelopment.aegis.encoding;

public class HexException extends Exception {
    public HexException(String message) {
        super(message);
    }
}
