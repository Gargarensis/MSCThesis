package com.beemdevelopment.aegis.db;

public class DatabaseManagerException extends Exception {
    public DatabaseManagerException(Throwable cause) {
        super(cause);
    }
}
