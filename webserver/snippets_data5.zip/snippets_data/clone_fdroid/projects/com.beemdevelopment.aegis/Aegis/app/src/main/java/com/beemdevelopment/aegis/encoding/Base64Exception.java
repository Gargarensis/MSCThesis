package com.beemdevelopment.aegis.encoding;

public class Base64Exception extends Exception {
    public Base64Exception(Throwable cause) {
        super(cause);
    }
}
