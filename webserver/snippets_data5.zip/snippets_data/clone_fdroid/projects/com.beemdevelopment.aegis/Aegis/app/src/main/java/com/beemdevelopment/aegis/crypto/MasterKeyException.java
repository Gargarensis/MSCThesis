package com.beemdevelopment.aegis.crypto;

public class MasterKeyException extends Exception {
    public MasterKeyException(Throwable cause) {
        super(cause);
    }
}
